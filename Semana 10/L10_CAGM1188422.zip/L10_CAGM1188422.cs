﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");


namespace ConsoleApp6
{
    class Program
    {
        static void Main(string[] args)
        {
            int cantidad = 0;
            int contador = 0;
            string usuario;
            string contraseña;
            bool res = false;


            while (cantidad < 3)
            {
                Console.WriteLine("Ingrese el usuario");
                usuario = Console.ReadLine();
                Console.WriteLine("Coloque contraseña");
                contraseña = Console.ReadLine();

                res = login(usuario, contraseña);
                if (res == true)
                {
                    cantidad = 3;
                    Console.WriteLine("Ingreso accedido");
                }
                else
                {
                    Console.WriteLine("Error al ingresar ingrese de nuevo, su cantidad de intentos es: " + contador);
                    contador++;
                    cantidad++;
                }
                if (contador == 3)
                {
                    Console.WriteLine("Se han agotado las oportunidades");
                }

            }

            Console.ReadKey();
        }
        public static bool login(string usuario, string contra)
        {
            if (usuario == "usuario1" && contra == "asdasd")
            {
                return true;
            }
            else
            {
                return false;

            }
        }
    }
}