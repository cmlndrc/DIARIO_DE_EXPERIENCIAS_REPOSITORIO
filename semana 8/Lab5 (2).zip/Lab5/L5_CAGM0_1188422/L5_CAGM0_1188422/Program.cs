﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L5_CAGM0_1188422
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numeroEntero;

            Console.WriteLine("Ejercicio1");
            Console.WriteLine("Ingerese un numero entero");

            numeroEntero = Convert.ToInt32(Console.ReadLine());

            if (numeroEntero > 0)
            {
                Console.WriteLine("Resultado: positivo");
            }
            else if (numeroEntero < 0)
            {
                Console.WriteLine("Resultado: negativo");
            }
            else if (numeroEntero == 0)
            {
                Console.WriteLine("Resultado: es igual a 0");
            }
            Console.ReadKey();
        }
    }
}
