﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L5_CAGM_11884222
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int DIA;

            Console.WriteLine("Ejercicio 2");
            Console.WriteLine("ingrese un número para el dia de la semana");
            DIA = Convert.ToInt32(Console.ReadLine());

            if (DIA == 1)
            {
                Console.WriteLine("el dia es lunes");
            }
            if (DIA == 2)
            {
                Console.WriteLine("el dia es martes");
            }
            if (DIA == 3)
            {
                Console.WriteLine("el dia es miercoles");
            }
            if (DIA == 4)
            {
                Console.WriteLine("el dia es jueves");
            }
            if (DIA == 5)
            {
                Console.WriteLine("el dia es viernes");
            }
            if (DIA == 6)
            {
                Console.WriteLine("el dia es sabado");
            }
            if (DIA == 7)
            {
                Console.WriteLine("el dia es domingo");
            }
            if (DIA > 7)
            {
                Console.WriteLine("error");
            }
            Console.ReadKey();        
        }
    }
}